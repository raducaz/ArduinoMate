package com.gmail.raducaz.arduinomate.model;

import java.util.Date;

/**
 * Created by Radu.Cazacu on 11/27/2017.
 */


public interface RemoteQueue {
    long getId();
    String getName();
    Date getDate();
}