package com.gmail.raducaz.arduinomate.processes;

public interface TaskInterface {
    void execute();
}
