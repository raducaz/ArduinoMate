package com.gmail.raducaz.arduinomate.service;

public class FunctionExecutorService {
    // TODO: Add here code to handle the execution on PinStateChange scheduler events

    // Service should start the scheduler (based on some configuration)
    // When event is triggered then this service will start the function (based on some configuration or in code)
}
