package com.gmail.raducaz.arduinomate.ui;

import com.gmail.raducaz.arduinomate.model.ExecutionLog;

public interface ClickCallbackAllExecutionLog {
    void onClick(ExecutionLog executionLog);
}
