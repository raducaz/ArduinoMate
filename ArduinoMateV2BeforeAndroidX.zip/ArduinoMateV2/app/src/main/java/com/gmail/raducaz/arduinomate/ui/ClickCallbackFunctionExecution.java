package com.gmail.raducaz.arduinomate.ui;

import com.gmail.raducaz.arduinomate.model.FunctionExecution;

public interface ClickCallbackFunctionExecution {
    void onClick(FunctionExecution execution);
}
