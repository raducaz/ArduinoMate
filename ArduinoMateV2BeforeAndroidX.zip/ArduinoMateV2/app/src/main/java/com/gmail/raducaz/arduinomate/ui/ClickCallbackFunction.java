package com.gmail.raducaz.arduinomate.ui;

import android.view.View;

import com.gmail.raducaz.arduinomate.model.Function;

public interface ClickCallbackFunction {
    void onClick(View v, Function function);
}
