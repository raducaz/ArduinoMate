package com.gmail.raducaz.arduinomate.ui;

import android.view.View;

import com.gmail.raducaz.arduinomate.model.Device;

public interface ClickCallbackDevice {
    void onClick(View v, Device device);
}
